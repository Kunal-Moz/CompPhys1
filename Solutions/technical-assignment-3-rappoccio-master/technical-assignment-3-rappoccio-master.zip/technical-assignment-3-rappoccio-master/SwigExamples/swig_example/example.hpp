#ifndef EXAMPLE_HPP
#define EXAMPLE_HPP

#include <vector>

// Declare your function normally
int sum_int(std::vector<int> const & vec);

#endif // EXAMPLE_HPP
