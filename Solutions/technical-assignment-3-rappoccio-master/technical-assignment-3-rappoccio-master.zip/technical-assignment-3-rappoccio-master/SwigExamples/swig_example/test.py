from example import *
import numpy as np

a = vector_int([1,2,3])
x = sum_int(a)
print x

