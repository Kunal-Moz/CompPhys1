echo "Always look on the bright side of life" > bright.txt
echo "If life is jolly rotten, there's something you've forgotten" > forgotten.txt
cat bright.txt forgotten.txt > song.txt
cat song.txt
