#include <iostream>
int main(void) {

  std::cout << -5 << std::endl;
  std::cout << 5 + 3 <<std::endl;
  std::cout << 5 * 3 <<std::endl;
  std::cout << 21.32 / 38.0 << std::endl;
  std::cout << 12 / 4 << std::endl;
  std::cout << 13 / 4 << std::endl;
  std::cout << 13. / 4. << std::endl;
  return 0;
}
