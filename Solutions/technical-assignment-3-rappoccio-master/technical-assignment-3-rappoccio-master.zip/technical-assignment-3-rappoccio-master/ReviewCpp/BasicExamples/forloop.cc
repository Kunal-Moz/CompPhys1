#include <iostream>
int main(void){

  for ( unsigned int i = 0; i < 10; ++i) {
    std::cout << i << ", ";
  }
  std::cout << std::endl;
  return 0;
}
