#include <iostream>

int main(void) {
  double d = 22000000000000.0;
  int i = d;
  std::cout << "d = " << d << ", i = " << i << std::endl;
  return 0;
}
